import React, { useEffect } from "react";
import ReactDOM from "react-dom/client";
import "./style.css";
import "./animation.css";
import runAnimations from "./scripts";
const App = () => {
  useEffect(() => {
    runAnimations();
  }, []);
  return (
    <div className="parent-div">
      <div className="node-271194" id="id-271194">
        {/* Rectangle 56 */}
        <div className="node-271166" id="id-271166"></div>
        {/* Menu Bar */}
        <div className="node-271167" id="id-271167"></div>
        {/* Home 3 */}
        <div className="node-271168" id="id-271168">
          <div className="nodeBg-271168" id="id-bg-271168">
            {" "}
          </div>
        </div>
        {/* Search 3 */}
        <div className="node-271169" id="id-271169">
          <div className="nodeBg-271169" id="id-bg-271169">
            {" "}
          </div>
        </div>
        {/* robot1 */}
        <div className="node-271170" id="id-271170">
          <div className="nodeBg-271170" id="id-bg-271170">
            {" "}
          </div>
        </div>
        {/* Rectangle 57 */}
        <div className="node-271179" id="id-271179"></div>
        {/* facebookicon512x512seb542ju 4 */}
        <div className="node-271185" id="id-271185">
          <div className="nodeBg-271185" id="id-bg-271185">
            {" "}
          </div>
        </div>
        {/* Instagramicon 4 */}
        <div className="node-271187" id="id-271187">
          <div className="nodeBg-271187" id="id-bg-271187">
            {" "}
          </div>
        </div>
        {/* istockphoto1494579261612x612 5 */}
        <div className="node-271191" id="id-271191">
          <div className="nodeBg-271191" id="id-bg-271191">
            {" "}
          </div>
        </div>
        {/* mailaddicon2048x2048cb6fejn9 5 */}
        <div className="node-271192" id="id-271192">
          <div className="nodeBg-271192" id="id-bg-271192">
            {" "}
          </div>
        </div>
        {/* LogoofTwitter 4 */}
        <div className="node-271193" id="id-271193">
          <div className="nodeBg-271193" id="id-bg-271193">
            {" "}
          </div>
        </div>
        {/*  */}
        <div className="node-271172" id="id-271172">
          <span className="node-271172-0">{"<"}</span>
          <span className="node-271172-1"> &nbsp; &nbsp;{""}</span>
        </div>
        {/* Contact Us */}
        <div className="node-271173" id="id-271173">
          <span className="node-271173-0">{"Contact Us"}</span>
        </div>
        {/* You can get in touch through below platforms Our team will reach out to you as soon as possible */}
        <div className="node-271176" id="id-271176">
          <span className="node-271176-0">
            {"You can get in touch through below platforms. "} <br />{" "}
            {" Our team will reach out to you as soon as "}&nbsp;{""} <br />{" "}
            {" possible."}
          </span>
        </div>
        {/* Customer Support */}
        <div className="node-271177" id="id-271177">
          <span className="node-271177-0">{"Customer Support "}</span>
        </div>
        {/* Social Media Platforms */}
        <div className="node-271178" id="id-271178">
          <span className="node-271178-0">{"Social Media Platforms"}</span>
        </div>
        {/* Contact Number 09067720310 */}
        <div className="node-271180" id="id-271180">
          <span className="node-271180-0">
            {"Contact Number "} <br />{" "}
          </span>
          <span className="node-271180-1">{"09067720310"}</span>
        </div>
        {/* Email Address quickmindfITgmailcom */}
        <div className="node-271186" id="id-271186">
          <span className="node-271186-0">
            {"Email Address "} <br />{" "}
          </span>
          <span className="node-271186-1">{"quickmindfIT@gmail.com"}</span>
        </div>
        {/* Instagram quickmindfIT */}
        <div className="node-271188" id="id-271188">
          <span className="node-271188-0">
            {"Instagram "} <br />{" "}
          </span>
          <span className="node-271188-1">{"quick_mindfIT"}</span>
        </div>
        {/* Facebook Quick MindfIT */}
        <div className="node-271190" id="id-271190">
          <span className="node-271190-0">
            {"Facebook "} <br />{" "}
          </span>
          <span className="node-271190-1">{"Quick MindfIT"}</span>
        </div>
        {/* Twitter qckmndft */}
        <div className="node-271195" id="id-271195">
          <span className="node-271195-0">
            {"Twitter "} <br />{" "}
          </span>
          <span className="node-271195-1">{"qck_mndft"}</span>
        </div>
        {/* Menu Bar2 */}
        <div className="node-271174" id="id-271174">
          <div className="nodeBg-271174" id="id-bg-271174"></div>
        </div>
        {/* Menu Bar3 */}
        <div className="node-271175" id="id-271175">
          <div className="nodeBg-271175" id="id-bg-271175"></div>
        </div>
        {/* Rectangle 58 */}
        <div className="node-271181" id="id-271181">
          <div className="nodeBg-271181" id="id-bg-271181"></div>
        </div>
        {/* Rectangle 59 */}
        <div className="node-271182" id="id-271182">
          <div className="nodeBg-271182" id="id-bg-271182"></div>
        </div>
        {/* Rectangle 60 */}
        <div className="node-271183" id="id-271183">
          <div className="nodeBg-271183" id="id-bg-271183"></div>
        </div>
        {/* Rectangle 61 */}
        <div className="node-271184" id="id-271184">
          <div className="nodeBg-271184" id="id-bg-271184"></div>
        </div>
      </div>
    </div>
  );
};
ReactDOM.createRoot(document.getElementById("dualite-root")).render(<App />);
