function runAnimations() {}
export default runAnimations;
