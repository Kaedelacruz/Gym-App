import React, { useEffect } from "react";
import ReactDOM from "react-dom/client";
import "./style.css";
import "./animation.css";
import runAnimations from "./scripts";
const App = () => {
  useEffect(() => {
    runAnimations();
  }, []);
  return (
    <div className="parent-div">
      <div className="node-1404" id="id-1404">
        {/* Ellipse 3 */}
        <div className="node-14156" id="id-14156"></div>
        {/* Rectangle 17 */}
        <div className="node-14149" id="id-14149"></div>
        {/* Rectangle 32 */}
        <div className="node-14159" id="id-14159"></div>
        {/* Rectangle 33 */}
        <div className="node-14162" id="id-14162"></div>
        {/* Go Back */}
        <div className="node-14150" id="id-14150">
          <div className="nodeBg-14150" id="id-bg-14150">
            {" "}
          </div>
        </div>
        {/* Rectangle 31 */}
        <div className="node-14157" id="id-14157">
          <div className="nodeBg-14157" id="id-bg-14157">
            {" "}
          </div>
        </div>
        {/* Ellipsis */}
        <div className="node-14160" id="id-14160">
          <div className="nodeBg-14160" id="id-bg-14160">
            {" "}
          </div>
        </div>
        {/* Help */}
        <div className="node-14153" id="id-14153">
          <div className="nodeBg-14153" id="id-bg-14153">
            {" "}
          </div>
        </div>
        {/* Facebook Like */}
        <div className="node-14155" id="id-14155">
          <div className="nodeBg-14155" id="id-bg-14155">
            {" "}
          </div>
        </div>
        {/* Paper Plane */}
        <div className="node-14161" id="id-14161">
          <div className="nodeBg-14161" id="id-bg-14161">
            {" "}
          </div>
        </div>
        {/* FlexFIT Chatbot */}
        <div className="node-14152" id="id-14152">
          <span className="node-14152-0">{"FlexFIT"}</span>
          <span className="node-14152-1">
            {" "}
            <br />{" "}
          </span>
          <span className="node-14152-2">{"Chatbot"}</span>
        </div>
        {/* Welcome User How can I assist you today */}
        <div className="node-14163" id="id-14163">
          <span className="node-14163-0">
            {"Welcome, User. How can I assist you today?"}
          </span>
        </div>
      </div>
    </div>
  );
};
ReactDOM.createRoot(document.getElementById("dualite-root")).render(<App />);
