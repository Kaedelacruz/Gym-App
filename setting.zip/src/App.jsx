import React, { useEffect } from "react";
import ReactDOM from "react-dom/client";
import "./style.css";
import "./animation.css";
import runAnimations from "./scripts";
const App = () => {
  useEffect(() => {
    runAnimations();
  }, []);
  return (
    <div className="parent-div">
      <div className="node-1394" id="id-1394">
        {/* Categories */}
        <div className="node-14148" id="id-14148">
          {/* Cardiovascular Category */}
          <div className="node-805" id="id-805"></div>
          {/* Strength Category */}
          <div className="node-806" id="id-806"></div>
          {/* Endurance Category */}
          <div className="node-807" id="id-807"></div>
          {/* Flexibility Category */}
          <div className="node-808" id="id-808"></div>
        </div>
        {/* Discover */}
        <div className="node-1403" id="id-1403">
          {/* Profile ICon */}
          <div className="node-14116" id="id-14116">
            <div className="nodeBg-14116" id="id-bg-14116">
              {" "}
            </div>
          </div>
          {/* Workout button */}
          <div className="node-14123" id="id-14123"></div>
          {/* Strength Button */}
          <div className="node-14124" id="id-14124"></div>
          {/* Mindfulness button */}
          <div className="node-14125" id="id-14125"></div>
          {/* Nutrition Button */}
          <div className="node-14126" id="id-14126"></div>
          {/* Workout Butoon */}
          <div className="node-14127" id="id-14127"></div>
          {/* Menu Bar */}
          <div className="node-1415" id="id-1415"></div>
          {/* Search Bar */}
          <div className="node-14120" id="id-14120"></div>
          {/* Go Back */}
          <div className="node-14151" id="id-14151">
            <div className="nodeBg-14151" id="id-bg-14151">
              {" "}
            </div>
          </div>
          {/* home 3 */}
          <div className="node-14164" id="id-14164">
            <div className="nodeBg-14164" id="id-bg-14164">
              {" "}
            </div>
          </div>
          {/* robot4 */}
          <div className="node-14167" id="id-14167">
            <div className="nodeBg-14167" id="id-bg-14167">
              {" "}
            </div>
          </div>
          {/* Search */}
          <div className="node-14121" id="id-14121">
            <div className="nodeBg-14121" id="id-bg-14121">
              {" "}
            </div>
          </div>
          {/* Search 5 */}
          <div className="node-4017" id="id-4017">
            <div className="nodeBg-4017" id="id-bg-4017">
              {" "}
            </div>
          </div>
          {/* Line 1 */}
          <div className="node-14133" id="id-14133"></div>
          {/* Line 2 */}
          <div className="node-14145" id="id-14145"></div>
          {/* Hello How can we assist you today */}
          <div className="node-14119" id="id-14119">
            <span className="node-14119-0">{"Hello,"}</span>
            <span className="node-14119-1">
              {" "}
              <br />{" "}
            </span>
            <span className="node-14119-2">
              {"How can we assist you today?"}
            </span>
          </div>
          {/* Worko */}
          <div className="node-14128" id="id-14128">
            <span className="node-14128-0">{"Worko"}</span>
          </div>
          {/* Strength */}
          <div className="node-14129" id="id-14129">
            <span className="node-14129-0">{"Strength"}</span>
          </div>
          {/* Mindfulness */}
          <div className="node-14130" id="id-14130">
            <span className="node-14130-0">{"Mindfulness"}</span>
          </div>
          {/* Nutrition */}
          <div className="node-14131" id="id-14131">
            <span className="node-14131-0">{"Nutrition"}</span>
          </div>
          {/* Workout */}
          <div className="node-14132" id="id-14132">
            <span className="node-14132-0">{"Workout"}</span>
          </div>
          {/* 214k Photos 24 videos 7 Users */}
          <div className="node-14134" id="id-14134">
            <span className="node-14134-0">
              {"214k Photos "}&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;{""}
            </span>
            <span className="node-14134-1">
              {"24 videos "}&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;{"7 Users"}
            </span>
          </div>
          {/* Load more */}
          <div className="node-14147" id="id-14147">
            <span className="node-14147-0">{"Load more"}</span>
          </div>
          {/* Photos */}
          <div className="node-14144" id="id-14144">
            {/* Rectangle 21 */}
            <div className="node-14135" id="id-14135"></div>
            {/* Rectangle 24 */}
            <div className="node-14138" id="id-14138"></div>
            {/* Rectangle 22 */}
            <div className="node-14136" id="id-14136"></div>
            {/* Rectangle 25 */}
            <div className="node-14139" id="id-14139"></div>
            {/* Rectangle 26 */}
            <div className="node-14140" id="id-14140"></div>
            {/* Rectangle 23 */}
            <div className="node-14137" id="id-14137"></div>
            {/* Rectangle 27 */}
            <div className="node-14141" id="id-14141"></div>
            {/* Rectangle 29 */}
            <div className="node-14143" id="id-14143"></div>
            {/* Rectangle 28 */}
            <div className="node-14142" id="id-14142"></div>
          </div>
        </div>
        {/* Pick */}
        <div className="node-745" id="id-745"></div>
        {/* Vector */}
        <div className="node-336279" id="id-336279">
          <div className="nodeBg-336279" id="id-bg-336279"></div>
        </div>
        {/* Ellipse 1 */}
        <div className="node-1398" id="id-1398">
          <div className="nodeBg-1398" id="id-bg-1398">
            {" "}
          </div>
        </div>
        {/* Search Restrictions */}
        <div className="node-747" id="id-747"></div>
        {/* User Icon */}
        <div className="node-7412" id="id-7412">
          <div className="nodeBg-7412" id="id-bg-7412">
            {" "}
          </div>
        </div>
        {/* Rectangle 15 */}
        <div className="node-1397" id="id-1397"></div>
        {/* Language */}
        <div className="node-13913" id="id-13913"></div>
        {/* Notifications */}
        <div className="node-13914" id="id-13914"></div>
        {/* App Settings */}
        <div className="node-13915" id="id-13915"></div>
        {/* Support Center */}
        <div className="node-13916" id="id-13916"></div>
        {/* Menu Bar */}
        <div className="node-13927" id="id-13927"></div>
        {/* Home 1 */}
        <div className="node-13932" id="id-13932">
          <div className="nodeBg-13932" id="id-bg-13932">
            {" "}
          </div>
        </div>
        {/* Search 1 */}
        <div className="node-13933" id="id-13933">
          <div className="nodeBg-13933" id="id-bg-13933">
            {" "}
          </div>
        </div>
        {/* robot1 */}
        <div className="node-13934" id="id-13934">
          <div className="nodeBg-13934" id="id-bg-13934">
            {" "}
          </div>
        </div>
        {/* Rectangle 1 */}
        <div className="node-742" id="id-742"></div>
        {/* Rectangle 16 */}
        <div className="node-13958" id="id-13958"></div>
        {/* Rectangle 2 */}
        <div className="node-743" id="id-743"></div>
        {/* Rectangle 14 */}
        <div className="node-9022" id="id-9022">
          <div className="nodeBg-9022" id="id-bg-9022">
            {" "}
          </div>
        </div>
        {/* Progress Box */}
        <div className="node-744" id="id-744"></div>
        {/* Blank first box */}
        <div className="node-849" id="id-849"></div>
        {/* Blank first box2 */}
        <div className="node-13962" id="id-13962"></div>
        {/* 21 */}
        <div className="node-9025" id="id-9025">
          <div className="nodeBg-9025" id="id-bg-9025">
            {" "}
          </div>
        </div>
        {/* 22 */}
        <div className="node-8410" id="id-8410"></div>
        {/* 23 */}
        <div className="node-9026" id="id-9026">
          <div className="nodeBg-9026" id="id-bg-9026">
            {" "}
          </div>
        </div>
        {/* 24 */}
        <div className="node-8411" id="id-8411"></div>
        {/* Search Bar */}
        <div className="node-746" id="id-746"></div>
        {/* Search Bar2 */}
        <div className="node-13963" id="id-13963"></div>
        {/* Heart with Pulse */}
        <div className="node-965" id="id-965">
          <div className="nodeBg-965" id="id-bg-965">
            {" "}
          </div>
        </div>
        {/* Barbell */}
        <div className="node-966" id="id-966">
          <div className="nodeBg-966" id="id-bg-966">
            {" "}
          </div>
        </div>
        {/* Stopwatch */}
        <div className="node-967" id="id-967">
          <div className="nodeBg-967" id="id-bg-967">
            {" "}
          </div>
        </div>
        {/* Yoga */}
        <div className="node-968" id="id-968">
          <div className="nodeBg-968" id="id-bg-968">
            {" "}
          </div>
        </div>
        {/* Bell */}
        <div className="node-14117" id="id-14117">
          <div className="nodeBg-14117" id="id-bg-14117">
            {" "}
          </div>
        </div>
        {/* Line Width */}
        <div className="node-14122" id="id-14122">
          <div className="nodeBg-14122" id="id-bg-14122">
            {" "}
          </div>
        </div>
        {/* Search 3 */}
        <div className="node-14169" id="id-14169">
          <div className="nodeBg-14169" id="id-bg-14169">
            {" "}
          </div>
        </div>
        {/* Search 4 */}
        <div className="node-4016" id="id-4016">
          <div className="nodeBg-4016" id="id-bg-4016">
            {" "}
          </div>
        </div>
        {/* robot3 */}
        <div className="node-14171" id="id-14171">
          <div className="nodeBg-14171" id="id-bg-14171">
            {" "}
          </div>
        </div>
        {/* Home 2 */}
        <div className="node-4018" id="id-4018">
          <div className="nodeBg-4018" id="id-bg-4018">
            {" "}
          </div>
        </div>
        {/* Rectangle 36 */}
        <div className="node-2532" id="id-2532"></div>
        {/* Rectangle 21 */}
        <div className="node-25330" id="id-25330"></div>
        {/* Rectangle 39 */}
        <div className="node-26764" id="id-26764"></div>
        {/* Rectangle 37 */}
        <div className="node-2537" id="id-2537"></div>
        {/* Search 2 */}
        <div className="node-2539" id="id-2539">
          <div className="nodeBg-2539" id="id-bg-2539">
            {" "}
          </div>
        </div>
        {/* Go Back */}
        <div className="node-322232" id="id-322232">
          <div className="nodeBg-322232" id="id-bg-322232">
            {" "}
          </div>
        </div>
        {/* Notif 1 */}
        <div className="node-26611" id="id-26611">
          <div className="nodeBg-26611" id="id-bg-26611">
            {" "}
          </div>
        </div>
        {/* Rectangle 56 */}
        <div className="node-271166" id="id-271166"></div>
        {/* Home 3 */}
        <div className="node-271168" id="id-271168">
          <div className="nodeBg-271168" id="id-bg-271168">
            {" "}
          </div>
        </div>
        {/* Rectangle 57 */}
        <div className="node-271179" id="id-271179"></div>
        {/* facebookicon512x512seb542ju 4 */}
        <div className="node-271185" id="id-271185">
          <div className="nodeBg-271185" id="id-bg-271185">
            {" "}
          </div>
        </div>
        {/* Instagramicon 4 */}
        <div className="node-271187" id="id-271187">
          <div className="nodeBg-271187" id="id-bg-271187">
            {" "}
          </div>
        </div>
        {/* istockphoto1494579261612x612 5 */}
        <div className="node-271191" id="id-271191">
          <div className="nodeBg-271191" id="id-bg-271191">
            {" "}
          </div>
        </div>
        {/* mailaddicon2048x2048cb6fejn9 5 */}
        <div className="node-271192" id="id-271192">
          <div className="nodeBg-271192" id="id-bg-271192">
            {" "}
          </div>
        </div>
        {/* LogoofTwitter 4 */}
        <div className="node-271193" id="id-271193">
          <div className="nodeBg-271193" id="id-bg-271193">
            {" "}
          </div>
        </div>
        {/* transparenttechnicalsupporticonhelpicononlinemarketing5f6c696b9ce1a8 1 */}
        <div className="node-26772" id="id-26772">
          <div className="nodeBg-26772" id="id-bg-26772">
            {" "}
          </div>
        </div>
        {/* Input */}
        <div className="node-26773" id="id-26773"></div>
        {/* Input2 */}
        <div className="node-26774" id="id-26774"></div>
        {/* Input3 */}
        <div className="node-26775" id="id-26775"></div>
        {/* Input4 */}
        <div className="node-26776" id="id-26776"></div>
        {/* Vector2 */}
        <div className="node-336280" id="id-336280">
          <div className="nodeBg-336280" id="id-bg-336280"></div>
        </div>
        {/* Vector3 */}
        <div className="node-336281" id="id-336281">
          <div className="nodeBg-336281" id="id-bg-336281"></div>
        </div>
        {/* Menu Bar2 */}
        <div className="node-271174" id="id-271174">
          <div className="nodeBg-271174" id="id-bg-271174"></div>
        </div>
        {/* Menu Bar3 */}
        <div className="node-271175" id="id-271175">
          <div className="nodeBg-271175" id="id-bg-271175"></div>
        </div>
        {/* Rectangle 58 */}
        <div className="node-271181" id="id-271181">
          <div className="nodeBg-271181" id="id-bg-271181"></div>
        </div>
        {/* Rectangle 59 */}
        <div className="node-271182" id="id-271182">
          <div className="nodeBg-271182" id="id-bg-271182"></div>
        </div>
        {/* Rectangle 60 */}
        <div className="node-271183" id="id-271183">
          <div className="nodeBg-271183" id="id-bg-271183"></div>
        </div>
        {/* Rectangle 61 */}
        <div className="node-271184" id="id-271184">
          <div className="nodeBg-271184" id="id-bg-271184"></div>
        </div>
        {/*  icon radio button off outline */}
        <div className="node-336269" id="id-336269">
          {/* Vector */}
          <div className="node-336270" id="id-336270">
            <div className="nodeBg-336270" id="id-bg-336270"></div>
          </div>
          {/* Vector2 */}
          <div className="node-336271" id="id-336271">
            <div className="nodeBg-336271" id="id-bg-336271"></div>
          </div>
        </div>
        {/*  icon radio button off outline2 */}
        <div className="node-3562" id="id-3562">
          {/* Vector */}
          <div className="node-3563" id="id-3563">
            <div className="nodeBg-3563" id="id-bg-3563"></div>
          </div>
          {/* Vector2 */}
          <div className="node-3564" id="id-3564">
            <div className="nodeBg-3564" id="id-bg-3564"></div>
          </div>
        </div>
        {/*  icon radio button off outline3 */}
        <div className="node-336272" id="id-336272">
          {/* Vector */}
          <div className="node-336273" id="id-336273">
            <div className="nodeBg-336273" id="id-bg-336273"></div>
          </div>
          {/* Vector2 */}
          <div className="node-336274" id="id-336274">
            <div className="nodeBg-336274" id="id-bg-336274"></div>
          </div>
        </div>
        {/*  icon radio button off outline4 */}
        <div className="node-336275" id="id-336275">
          {/* Vector */}
          <div className="node-336276" id="id-336276">
            <div className="nodeBg-336276" id="id-bg-336276"></div>
          </div>
          {/* Vector2 */}
          <div className="node-336277" id="id-336277">
            <div className="nodeBg-336277" id="id-bg-336277"></div>
          </div>
        </div>
        {/* Settings */}
        <div className="node-1396" id="id-1396">
          <span className="node-1396-0">{"Settings"}</span>
        </div>
        {/* Profile Details */}
        <div className="node-13924" id="id-13924">
          <span className="node-13924-0">{"Profile Details"}</span>
        </div>
        {/* Language2 */}
        <div className="node-1399" id="id-1399">
          <span className="node-1399-0">{"Language"}</span>
        </div>
        {/* Notifications2 */}
        <div className="node-13921" id="id-13921">
          <span className="node-13921-0">{"Notifications"}</span>
        </div>
        {/* About Us */}
        <div className="node-13922" id="id-13922">
          <span className="node-13922-0">{"About Us"}</span>
        </div>
        {/* Tech Support */}
        <div className="node-13923" id="id-13923">
          <span className="node-13923-0">{"Tech Support"}</span>
        </div>
        {/* Edit Profile */}
        <div className="node-13910" id="id-13910">
          <span className="node-13910-0">{"Edit Profile"}</span>
        </div>
        {/*  */}
        <div className="node-13911" id="id-13911">
          <span className="node-13911-0">{">"}</span>
        </div>
        {/* 2 */}
        <div className="node-13917" id="id-13917">
          <span className="node-13917-0">{">"}</span>
        </div>
        {/* 3 */}
        <div className="node-13918" id="id-13918">
          <span className="node-13918-0">{">"}</span>
        </div>
        {/* 4 */}
        <div className="node-13919" id="id-13919">
          <span className="node-13919-0">{">"}</span>
        </div>
        {/* 5 */}
        <div className="node-13920" id="id-13920">
          <span className="node-13920-0">{">"}</span>
        </div>
        {/* Sign Out */}
        <div className="node-13926" id="id-13926">
          <span className="node-13926-0">{"Sign Out"}</span>
        </div>
        {/* Welcome Back */}
        <div className="node-9012" id="id-9012">
          <span className="node-9012-0">{"Welcome Back,"}</span>
        </div>
        {/* Youre new here Start your day now */}
        <div className="node-9027" id="id-9027">
          <span className="node-9027-0">
            {"You’re new here. Start your day now!"}
          </span>
        </div>
        {/* Please choose a workout routine */}
        <div className="node-9028" id="id-9028">
          <span className="node-9028-0">
            {"Please choose a workout routine."}
          </span>
        </div>
        {/* Most popular workouts */}
        <div className="node-9023" id="id-9023">
          <span className="node-9023-0">{"Most popular workouts"}</span>
        </div>
        {/* Quick and effective workouts */}
        <div className="node-9024" id="id-9024">
          <span className="node-9024-0">{"Quick and effective workouts"}</span>
        </div>
        {/* Users name */}
        <div className="node-9014" id="id-9014">
          <span className="node-9014-0">{"User’s name"}</span>
        </div>
        {/* Discover Find Trainers My Workout */}
        <div className="node-9015" id="id-9015">
          <span className="node-9015-0">
            {"Discover "}&nbsp; &nbsp; &nbsp; &nbsp;{" Find Trainers "}&nbsp;{" "}
            &nbsp; &nbsp;{" My Workout"}
          </span>
        </div>
        {/* Explore by category */}
        <div className="node-9017" id="id-9017">
          <span className="node-9017-0">{"Explore by category"}</span>
        </div>
        {/* Cardiovasc */}
        <div className="node-9018" id="id-9018">
          <span className="node-9018-0">{"Cardiovasc"}</span>
        </div>
        {/* Strength */}
        <div className="node-9019" id="id-9019">
          <span className="node-9019-0">{"Strength"}</span>
        </div>
        {/* Endurance */}
        <div className="node-9020" id="id-9020">
          <span className="node-9020-0">{"Endurance"}</span>
        </div>
        {/* Flexibility */}
        <div className="node-9021" id="id-9021">
          <span className="node-9021-0">{"Flexibility"}</span>
        </div>
        {/* CONTINUE */}
        <div className="node-25331" id="id-25331">
          <span className="node-25331-0">{"CONTINUE"}</span>
        </div>
        {/* English */}
        <div className="node-25315" id="id-25315">
          <span className="node-25315-0">{"English"}</span>
        </div>
        {/* Japanese */}
        <div className="node-25317" id="id-25317">
          <span className="node-25317-0">{"Japanese"}</span>
        </div>
        {/* Filipino */}
        <div className="node-25316" id="id-25316">
          <span className="node-25316-0">{"Filipino"}</span>
        </div>
        {/* Chinese */}
        <div className="node-25318" id="id-25318">
          <span className="node-25318-0">{"Chinese"}</span>
        </div>
        {/* Korean */}
        <div className="node-25327" id="id-25327">
          <span className="node-25327-0">{"Korean"}</span>
        </div>
        {/* Arabic */}
        <div className="node-25328" id="id-25328">
          <span className="node-25328-0">{"Arabic"}</span>
        </div>
        {/* Text */}
        <div className="node-2536" id="id-2536">
          <span className="node-2536-0">
            {" "}
            <br /> &nbsp;{""} <br /> &nbsp;{""} <br /> &nbsp;{""} <br /> &nbsp;
            {""} <br /> &nbsp;{""} <br /> &nbsp;{""} <br /> &nbsp;{""} <br />{" "}
            &nbsp;{""} <br />{" "}
          </span>
        </div>
        {/* Search */}
        <div className="node-2538" id="id-2538">
          <span className="node-2538-0">{"Search"}</span>
        </div>
        {/*  */}
        <div className="node-2668" id="id-2668">
          <span className="node-2668-0">{"="}</span>
        </div>
        {/* Clear All */}
        <div className="node-2669" id="id-2669">
          <span className="node-2669-0">{"Clear All"}</span>
        </div>
        {/* Notifications */}
        <div className="node-26610" id="id-26610">
          <span className="node-26610-0">{"Notifications"}</span>
        </div>
        {/* No notification yet */}
        <div className="node-26612" id="id-26612">
          <span className="node-26612-0">
            {"No notification "}&nbsp;{""} <br /> {" yet!"}
          </span>
        </div>
        {/*  */}
        <div className="node-271172" id="id-271172">
          <span className="node-271172-0">{"<"}</span>
          <span className="node-271172-1"> &nbsp; &nbsp;{""}</span>
        </div>
        {/* Contact Us */}
        <div className="node-271173" id="id-271173">
          <span className="node-271173-0">{"Contact Us"}</span>
        </div>
        {/* You can get in touch through below platforms Our team will reach out to you as soon as possible */}
        <div className="node-271176" id="id-271176">
          <span className="node-271176-0">
            {"You can get in touch through below platforms. "} <br />{" "}
            {" Our team will reach out to you as soon as "}&nbsp;{""} <br />{" "}
            {" possible."}
          </span>
        </div>
        {/* Customer Support */}
        <div className="node-271177" id="id-271177">
          <span className="node-271177-0">{"Customer Support "}</span>
        </div>
        {/* Social Media Platforms */}
        <div className="node-271178" id="id-271178">
          <span className="node-271178-0">{"Social Media Platforms"}</span>
        </div>
        {/* Contact Number 09067720310 */}
        <div className="node-271180" id="id-271180">
          <span className="node-271180-0">
            {"Contact Number "} <br />{" "}
          </span>
          <span className="node-271180-1">{"09067720310"}</span>
        </div>
        {/* Email Address quickmindfITgmailcom */}
        <div className="node-271186" id="id-271186">
          <span className="node-271186-0">
            {"Email Address "} <br />{" "}
          </span>
          <span className="node-271186-1">{"quickmindfIT@gmail.com"}</span>
        </div>
        {/* Instagram quickmindfIT */}
        <div className="node-271188" id="id-271188">
          <span className="node-271188-0">
            {"Instagram "} <br />{" "}
          </span>
          <span className="node-271188-1">{"quick_mindfIT"}</span>
        </div>
        {/* Facebook Quick MindfIT */}
        <div className="node-271190" id="id-271190">
          <span className="node-271190-0">
            {"Facebook "} <br />{" "}
          </span>
          <span className="node-271190-1">{"Quick MindfIT"}</span>
        </div>
        {/* Twitter qckmndft */}
        <div className="node-271195" id="id-271195">
          <span className="node-271195-0">
            {"Twitter "} <br />{" "}
          </span>
          <span className="node-271195-1">{"qck_mndft"}</span>
        </div>
        {/* Your Name */}
        <div className="node-26777" id="id-26777">
          <span className="node-26777-0">{"Your Name:"}</span>
        </div>
        {/* EMail Address */}
        <div className="node-26778" id="id-26778">
          <span className="node-26778-0">{"E-Mail Address:"}</span>
        </div>
        {/* Phone Number */}
        <div className="node-26779" id="id-26779">
          <span className="node-26779-0">{"Phone Number:"}</span>
        </div>
        {/* Problem DescriptionFeedback */}
        <div className="node-26780" id="id-26780">
          <span className="node-26780-0">
            {"Problem Description/Feedback:"}
          </span>
        </div>
        {/* button */}
        <div className="node-305198" id="id-305198">
          {/* Rectangle 20 */}
          <div className="node-13925" id="id-13925"></div>
        </div>
      </div>
    </div>
  );
};
ReactDOM.createRoot(document.getElementById("dualite-root")).render(<App />);
