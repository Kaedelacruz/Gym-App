import React, { useEffect } from "react";
import ReactDOM from "react-dom/client";
import "./style.css";
import "./animation.css";
import runAnimations from "./scripts";
const App = () => {
  useEffect(() => {
    runAnimations();
  }, []);
  return (
    <div className="parent-div">
      <div className="node-2562" id="id-2562">
        {/* Rectangle 36 */}
        <div className="node-2532" id="id-2532"></div>
        {/* Rectangle 21 */}
        <div className="node-25330" id="id-25330"></div>
        {/* Rectangle 39 */}
        <div className="node-26764" id="id-26764"></div>
        {/* Rectangle 37 */}
        <div className="node-2537" id="id-2537"></div>
        {/* Search 2 */}
        <div className="node-2539" id="id-2539">
          <div className="nodeBg-2539" id="id-bg-2539">
            {" "}
          </div>
        </div>
        {/* Go Back */}
        <div className="node-322232" id="id-322232">
          <div className="nodeBg-322232" id="id-bg-322232">
            {" "}
          </div>
        </div>
        {/* CONTINUE */}
        <div className="node-25331" id="id-25331">
          <span className="node-25331-0">{"CONTINUE"}</span>
        </div>
        {/* English */}
        <div className="node-25315" id="id-25315">
          <span className="node-25315-0">{"English"}</span>
        </div>
        {/* Japanese */}
        <div className="node-25317" id="id-25317">
          <span className="node-25317-0">{"Japanese"}</span>
        </div>
        {/* Filipino */}
        <div className="node-25316" id="id-25316">
          <span className="node-25316-0">{"Filipino"}</span>
        </div>
        {/* Chinese */}
        <div className="node-25318" id="id-25318">
          <span className="node-25318-0">{"Chinese"}</span>
        </div>
        {/* Korean */}
        <div className="node-25327" id="id-25327">
          <span className="node-25327-0">{"Korean"}</span>
        </div>
        {/* Arabic */}
        <div className="node-25328" id="id-25328">
          <span className="node-25328-0">{"Arabic"}</span>
        </div>
        {/* Text */}
        <div className="node-2536" id="id-2536">
          <span className="node-2536-0">
            {" "}
            <br /> &nbsp;{""} <br /> &nbsp;{""} <br /> &nbsp;{""} <br /> &nbsp;
            {""} <br /> &nbsp;{""} <br /> &nbsp;{""} <br /> &nbsp;{""} <br />{" "}
            &nbsp;{""} <br />{" "}
          </span>
        </div>
        {/* Search */}
        <div className="node-2538" id="id-2538">
          <span className="node-2538-0">{"Search"}</span>
        </div>
        {/* Vector */}
        <div className="node-336279" id="id-336279">
          <div className="nodeBg-336279" id="id-bg-336279"></div>
        </div>
        {/* Vector2 */}
        <div className="node-336280" id="id-336280">
          <div className="nodeBg-336280" id="id-bg-336280"></div>
        </div>
        {/* Vector3 */}
        <div className="node-336281" id="id-336281">
          <div className="nodeBg-336281" id="id-bg-336281"></div>
        </div>
        {/*  icon radio button off outline */}
        <div className="node-336269" id="id-336269">
          {/* Vector */}
          <div className="node-336270" id="id-336270">
            <div className="nodeBg-336270" id="id-bg-336270"></div>
          </div>
          {/* Vector2 */}
          <div className="node-336271" id="id-336271">
            <div className="nodeBg-336271" id="id-bg-336271"></div>
          </div>
        </div>
        {/*  icon radio button off outline2 */}
        <div className="node-3562" id="id-3562">
          {/* Vector */}
          <div className="node-3563" id="id-3563">
            <div className="nodeBg-3563" id="id-bg-3563"></div>
          </div>
          {/* Vector2 */}
          <div className="node-3564" id="id-3564">
            <div className="nodeBg-3564" id="id-bg-3564"></div>
          </div>
        </div>
        {/*  icon radio button off outline3 */}
        <div className="node-336272" id="id-336272">
          {/* Vector */}
          <div className="node-336273" id="id-336273">
            <div className="nodeBg-336273" id="id-bg-336273"></div>
          </div>
          {/* Vector2 */}
          <div className="node-336274" id="id-336274">
            <div className="nodeBg-336274" id="id-bg-336274"></div>
          </div>
        </div>
        {/*  icon radio button off outline4 */}
        <div className="node-336275" id="id-336275">
          {/* Vector */}
          <div className="node-336276" id="id-336276">
            <div className="nodeBg-336276" id="id-bg-336276"></div>
          </div>
          {/* Vector2 */}
          <div className="node-336277" id="id-336277">
            <div className="nodeBg-336277" id="id-bg-336277"></div>
          </div>
        </div>
      </div>
    </div>
  );
};
ReactDOM.createRoot(document.getElementById("dualite-root")).render(<App />);
