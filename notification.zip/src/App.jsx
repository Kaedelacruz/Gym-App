import React, { useEffect } from "react";
import ReactDOM from "react-dom/client";
import "./style.css";
import "./animation.css";
import runAnimations from "./scripts";
const App = () => {
  useEffect(() => {
    runAnimations();
  }, []);
  return (
    <div className="parent-div">
      <div className="node-2667" id="id-2667">
        {/* Rectangle 37 */}
        <div className="node-26765" id="id-26765"></div>
        {/* Notif 1 */}
        <div className="node-26611" id="id-26611">
          <div className="nodeBg-26611" id="id-bg-26611">
            {" "}
          </div>
        </div>
        {/* Menu Bar */}
        <div className="node-26613" id="id-26613"></div>
        {/* Home 1 */}
        <div className="node-26714" id="id-26714">
          <div className="nodeBg-26714" id="id-bg-26714">
            {" "}
          </div>
        </div>
        {/* Search 1 */}
        <div className="node-26715" id="id-26715">
          <div className="nodeBg-26715" id="id-bg-26715">
            {" "}
          </div>
        </div>
        {/* robot1 */}
        <div className="node-26716" id="id-26716">
          <div className="nodeBg-26716" id="id-bg-26716">
            {" "}
          </div>
        </div>
        {/*  */}
        <div className="node-2668" id="id-2668">
          <span className="node-2668-0">{"="}</span>
        </div>
        {/* Clear All */}
        <div className="node-2669" id="id-2669">
          <span className="node-2669-0">{"Clear All"}</span>
        </div>
        {/* Notifications */}
        <div className="node-26610" id="id-26610">
          <span className="node-26610-0">{"Notifications"}</span>
        </div>
        {/* No notification yet */}
        <div className="node-26612" id="id-26612">
          <span className="node-26612-0">
            {"No notification "}&nbsp;{""} <br /> {" yet!"}
          </span>
        </div>
      </div>
    </div>
  );
};
ReactDOM.createRoot(document.getElementById("dualite-root")).render(<App />);
