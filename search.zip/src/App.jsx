import React, { useEffect } from "react";
import ReactDOM from "react-dom/client";
import "./style.css";
import "./animation.css";
import runAnimations from "./scripts";
const App = () => {
  useEffect(() => {
    runAnimations();
  }, []);
  return (
    <div className="parent-div">
      <div className="node-1792" id="id-1792">
        {/* Welcome Back */}
        <div className="node-9012" id="id-9012">
          <span className="node-9012-0">{"Welcome Back,"}</span>
        </div>
        {/* Categories */}
        <div className="node-14148" id="id-14148">
          {/* Cardiovascular Category */}
          <div className="node-805" id="id-805"></div>
          {/* Strength Category */}
          <div className="node-806" id="id-806"></div>
          {/* Endurance Category */}
          <div className="node-807" id="id-807"></div>
          {/* Flexibility Category */}
          <div className="node-808" id="id-808"></div>
        </div>
        {/* Discover */}
        <div className="node-1403" id="id-1403">
          {/* Profile ICon */}
          <div className="node-14116" id="id-14116">
            <div className="nodeBg-14116" id="id-bg-14116">
              {" "}
            </div>
          </div>
          {/* Workout button */}
          <div className="node-14123" id="id-14123"></div>
          {/* Strength Button */}
          <div className="node-14124" id="id-14124"></div>
          {/* Mindfulness button */}
          <div className="node-14125" id="id-14125"></div>
          {/* Nutrition Button */}
          <div className="node-14126" id="id-14126"></div>
          {/* Workout Butoon */}
          <div className="node-14127" id="id-14127"></div>
          {/* Menu Bar */}
          <div className="node-1415" id="id-1415"></div>
          {/* Search Bar */}
          <div className="node-14120" id="id-14120"></div>
          {/* Go Back */}
          <div className="node-14151" id="id-14151">
            <div className="nodeBg-14151" id="id-bg-14151">
              {" "}
            </div>
          </div>
          {/* home 3 */}
          <div className="node-14164" id="id-14164">
            <div className="nodeBg-14164" id="id-bg-14164">
              {" "}
            </div>
          </div>
          {/* robot4 */}
          <div className="node-14167" id="id-14167">
            <div className="nodeBg-14167" id="id-bg-14167">
              {" "}
            </div>
          </div>
          {/* Search */}
          <div className="node-14121" id="id-14121">
            <div className="nodeBg-14121" id="id-bg-14121">
              {" "}
            </div>
          </div>
          {/* Search 5 */}
          <div className="node-4017" id="id-4017">
            <div className="nodeBg-4017" id="id-bg-4017">
              {" "}
            </div>
          </div>
          {/* Line 1 */}
          <div className="node-14133" id="id-14133"></div>
          {/* Line 2 */}
          <div className="node-14145" id="id-14145"></div>
          {/* Hello How can we assist you today */}
          <div className="node-14119" id="id-14119">
            <span className="node-14119-0">{"Hello,"}</span>
            <span className="node-14119-1">
              {" "}
              <br />{" "}
            </span>
            <span className="node-14119-2">
              {"How can we assist you today?"}
            </span>
          </div>
          {/* Worko */}
          <div className="node-14128" id="id-14128">
            <span className="node-14128-0">{"Worko"}</span>
          </div>
          {/* Strength */}
          <div className="node-14129" id="id-14129">
            <span className="node-14129-0">{"Strength"}</span>
          </div>
          {/* Mindfulness */}
          <div className="node-14130" id="id-14130">
            <span className="node-14130-0">{"Mindfulness"}</span>
          </div>
          {/* Nutrition */}
          <div className="node-14131" id="id-14131">
            <span className="node-14131-0">{"Nutrition"}</span>
          </div>
          {/* Workout */}
          <div className="node-14132" id="id-14132">
            <span className="node-14132-0">{"Workout"}</span>
          </div>
          {/* 214k Photos 24 videos 7 Users */}
          <div className="node-14134" id="id-14134">
            <span className="node-14134-0">
              {"214k Photos "}&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;{""}
            </span>
            <span className="node-14134-1">
              {"24 videos "}&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;{"7 Users"}
            </span>
          </div>
          {/* Load more */}
          <div className="node-14147" id="id-14147">
            <span className="node-14147-0">{"Load more"}</span>
          </div>
          {/* Photos */}
          <div className="node-14144" id="id-14144">
            {/* Rectangle 21 */}
            <div className="node-14135" id="id-14135"></div>
            {/* Rectangle 24 */}
            <div className="node-14138" id="id-14138"></div>
            {/* Rectangle 22 */}
            <div className="node-14136" id="id-14136"></div>
            {/* Rectangle 25 */}
            <div className="node-14139" id="id-14139"></div>
            {/* Rectangle 26 */}
            <div className="node-14140" id="id-14140"></div>
            {/* Rectangle 23 */}
            <div className="node-14137" id="id-14137"></div>
            {/* Rectangle 27 */}
            <div className="node-14141" id="id-14141"></div>
            {/* Rectangle 29 */}
            <div className="node-14143" id="id-14143"></div>
            {/* Rectangle 28 */}
            <div className="node-14142" id="id-14142"></div>
          </div>
        </div>
        {/* Pick */}
        <div className="node-745" id="id-745"></div>
        {/* Rectangle 1 */}
        <div className="node-742" id="id-742"></div>
        {/* User Icon */}
        <div className="node-7412" id="id-7412">
          <div className="nodeBg-7412" id="id-bg-7412">
            {" "}
          </div>
        </div>
        {/* Ellipse 3 */}
        <div className="node-14156" id="id-14156"></div>
        {/* Rectangle 16 */}
        <div className="node-13958" id="id-13958"></div>
        {/* Rectangle 15 */}
        <div className="node-13957" id="id-13957"></div>
        {/* Rectangle 2 */}
        <div className="node-743" id="id-743"></div>
        {/* Rectangle 14 */}
        <div className="node-9022" id="id-9022">
          <div className="nodeBg-9022" id="id-bg-9022">
            {" "}
          </div>
        </div>
        {/* Progress Box */}
        <div className="node-744" id="id-744"></div>
        {/* Blank first box */}
        <div className="node-849" id="id-849"></div>
        {/* Blank first box2 */}
        <div className="node-13962" id="id-13962"></div>
        {/* 21 */}
        <div className="node-9025" id="id-9025">
          <div className="nodeBg-9025" id="id-bg-9025">
            {" "}
          </div>
        </div>
        {/* 22 */}
        <div className="node-8410" id="id-8410"></div>
        {/* 23 */}
        <div className="node-9026" id="id-9026">
          <div className="nodeBg-9026" id="id-bg-9026">
            {" "}
          </div>
        </div>
        {/* 24 */}
        <div className="node-8411" id="id-8411"></div>
        {/* Search Bar */}
        <div className="node-746" id="id-746"></div>
        {/* Search Bar2 */}
        <div className="node-13963" id="id-13963"></div>
        {/* Menu Bar */}
        <div className="node-794" id="id-794"></div>
        {/* Heart with Pulse */}
        <div className="node-965" id="id-965">
          <div className="nodeBg-965" id="id-bg-965">
            {" "}
          </div>
        </div>
        {/* Barbell */}
        <div className="node-966" id="id-966">
          <div className="nodeBg-966" id="id-bg-966">
            {" "}
          </div>
        </div>
        {/* Stopwatch */}
        <div className="node-967" id="id-967">
          <div className="nodeBg-967" id="id-bg-967">
            {" "}
          </div>
        </div>
        {/* Yoga */}
        <div className="node-968" id="id-968">
          <div className="nodeBg-968" id="id-bg-968">
            {" "}
          </div>
        </div>
        {/* Bell */}
        <div className="node-14117" id="id-14117">
          <div className="nodeBg-14117" id="id-bg-14117">
            {" "}
          </div>
        </div>
        {/* Line Width */}
        <div className="node-14122" id="id-14122">
          <div className="nodeBg-14122" id="id-bg-14122">
            {" "}
          </div>
        </div>
        {/* Search 3 */}
        <div className="node-14169" id="id-14169">
          <div className="nodeBg-14169" id="id-bg-14169">
            {" "}
          </div>
        </div>
        {/* Search 4 */}
        <div className="node-4016" id="id-4016">
          <div className="nodeBg-4016" id="id-bg-4016">
            {" "}
          </div>
        </div>
        {/* robot3 */}
        <div className="node-14171" id="id-14171">
          <div className="nodeBg-14171" id="id-bg-14171">
            {" "}
          </div>
        </div>
        {/* Home 2 */}
        <div className="node-4018" id="id-4018">
          <div className="nodeBg-4018" id="id-bg-4018">
            {" "}
          </div>
        </div>
        {/* Rectangle 17 */}
        <div className="node-14149" id="id-14149"></div>
        {/* Rectangle 32 */}
        <div className="node-14159" id="id-14159"></div>
        {/* Rectangle 33 */}
        <div className="node-14162" id="id-14162"></div>
        {/* Go Back */}
        <div className="node-14150" id="id-14150">
          <div className="nodeBg-14150" id="id-bg-14150">
            {" "}
          </div>
        </div>
        {/* Rectangle 31 */}
        <div className="node-14157" id="id-14157">
          <div className="nodeBg-14157" id="id-bg-14157">
            {" "}
          </div>
        </div>
        {/* Ellipsis */}
        <div className="node-14160" id="id-14160">
          <div className="nodeBg-14160" id="id-bg-14160">
            {" "}
          </div>
        </div>
        {/* Help */}
        <div className="node-14153" id="id-14153">
          <div className="nodeBg-14153" id="id-bg-14153">
            {" "}
          </div>
        </div>
        {/* Facebook Like */}
        <div className="node-14155" id="id-14155">
          <div className="nodeBg-14155" id="id-bg-14155">
            {" "}
          </div>
        </div>
        {/* Paper Plane */}
        <div className="node-14161" id="id-14161">
          <div className="nodeBg-14161" id="id-bg-14161">
            {" "}
          </div>
        </div>
        {/* Youre new here Start your day now */}
        <div className="node-9027" id="id-9027">
          <span className="node-9027-0">
            {"You’re new here. Start your day now!"}
          </span>
        </div>
        {/* Please choose a workout routine */}
        <div className="node-9028" id="id-9028">
          <span className="node-9028-0">
            {"Please choose a workout routine."}
          </span>
        </div>
        {/* Most popular workouts */}
        <div className="node-9023" id="id-9023">
          <span className="node-9023-0">{"Most popular workouts"}</span>
        </div>
        {/* Quick and effective workouts */}
        <div className="node-9024" id="id-9024">
          <span className="node-9024-0">{"Quick and effective workouts"}</span>
        </div>
        {/* Users name */}
        <div className="node-9014" id="id-9014">
          <span className="node-9014-0">{"User’s name"}</span>
        </div>
        {/* Discover Find Trainers My Workout */}
        <div className="node-9015" id="id-9015">
          <span className="node-9015-0">
            {"Discover "}&nbsp; &nbsp; &nbsp; &nbsp;{" Find Trainers "}&nbsp;{" "}
            &nbsp; &nbsp;{" My Workout"}
          </span>
        </div>
        {/* Explore by category */}
        <div className="node-9017" id="id-9017">
          <span className="node-9017-0">{"Explore by category"}</span>
        </div>
        {/* Cardiovasc */}
        <div className="node-9018" id="id-9018">
          <span className="node-9018-0">{"Cardiovasc"}</span>
        </div>
        {/* Strength */}
        <div className="node-9019" id="id-9019">
          <span className="node-9019-0">{"Strength"}</span>
        </div>
        {/* Endurance */}
        <div className="node-9020" id="id-9020">
          <span className="node-9020-0">{"Endurance"}</span>
        </div>
        {/* Flexibility */}
        <div className="node-9021" id="id-9021">
          <span className="node-9021-0">{"Flexibility"}</span>
        </div>
        {/* FlexFIT Chatbot */}
        <div className="node-14152" id="id-14152">
          <span className="node-14152-0">{"FlexFIT"}</span>
          <span className="node-14152-1">
            {" "}
            <br />{" "}
          </span>
          <span className="node-14152-2">{"Chatbot"}</span>
        </div>
        {/* Welcome User How can I assist you today */}
        <div className="node-14163" id="id-14163">
          <span className="node-14163-0">
            {"Welcome, User. How can I assist you today?"}
          </span>
        </div>
        {/* Search Restrictions */}
        <div className="node-747" id="id-747"></div>
      </div>
    </div>
  );
};
ReactDOM.createRoot(document.getElementById("dualite-root")).render(<App />);
